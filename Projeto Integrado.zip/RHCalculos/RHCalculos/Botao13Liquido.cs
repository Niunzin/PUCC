﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RHCalculos
{
   public  class Botao13Liquido
    {
        public static float ObterValorTotal(float ValorBruto, int MesesDeFerias)
        {
            try
            {
                return (ValorBruto * MesesDeFerias) / 12;
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
