﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RHCalculos
{
    public class Geral
    {
        public static string FormatarParaReal(float Valor)
        {
            try
            {
                return string.Format("{0:R$#,##0.00;(R$#,##0.00)}", Valor);
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        public static float ObterINSS(float SalarioBruto)
        {
            try
            {
                float Aliquota = 0;
                float Contribuicao;

                if (SalarioBruto < 1556.94) Aliquota = 8;
                else if (SalarioBruto < 2594.92) Aliquota = 9;
                else if (SalarioBruto < 5189.82) Aliquota = 11;
                else Aliquota = 11;

                Contribuicao = SalarioBruto * (Aliquota / 100);
                if (Contribuicao > 570.88)
                    Contribuicao = (float)570.88;

                return Contribuicao;
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        public static float ObterIRRF(float BaseDeCalculo)
        {
            try
            {
                double Aliquota = 0;
                double ValorDeduzir = 0;
                float Valor;

                if (BaseDeCalculo < 1903.98) Aliquota = 0;
                else if (BaseDeCalculo < 2826.65) { Aliquota = 7.5; ValorDeduzir = 142.80; }
                else if (BaseDeCalculo < 3751.05) { Aliquota = 15; ValorDeduzir = 354.80; }
                else if (BaseDeCalculo < 4664.68) { Aliquota = 22.5; ValorDeduzir = 636.13; }
                else { Aliquota = 27.5; ValorDeduzir = 869.36; }

                Valor = (BaseDeCalculo * ((float)Aliquota / 100)) - (float)ValorDeduzir;
                return Valor;
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        public static float ObterBaseDeCalculo(float ValorTotalBruto, float INSS)
        {
            try
            {
                return ValorTotalBruto - INSS;
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
