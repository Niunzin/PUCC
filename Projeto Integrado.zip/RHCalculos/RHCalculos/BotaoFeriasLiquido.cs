﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RHCalculos
{
   public  class BotaoFeriasLiquido
    {
        public static float ObterValorTotalDeFerias(float ValorBruto, int DiasFerias)
        {
            try
            {
                return (ValorBruto * DiasFerias) / 30;
            }
            catch (Exception error)
            {
                throw error;
            }
        }

        public static float ObterFeriasLiquido(float BaseDeCalculo, float IRRF)
        {
            try
            {
                return BaseDeCalculo - IRRF;
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
