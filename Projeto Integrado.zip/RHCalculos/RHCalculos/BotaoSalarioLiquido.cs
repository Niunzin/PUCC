﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RHCalculos
{
    public class BotaoSalarioLiquido
    {
        public static float ObterTotalBruto(float SalarioBruto, float Bonus)
        {
            try
            {
                return SalarioBruto + Bonus;
            }
            catch (Exception error)
            {
                throw error;
            }
        }
    }
}
