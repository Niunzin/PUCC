﻿namespace SisRH
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPrincipal));
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.txtBonus = new System.Windows.Forms.TextBox();
            this.txtMesesTrabalhados = new System.Windows.Forms.TextBox();
            this.txtDiasDeFerias = new System.Windows.Forms.TextBox();
            this.txtINSS = new System.Windows.Forms.TextBox();
            this.txtBaseDeCalculo = new System.Windows.Forms.TextBox();
            this.txtIRRF = new System.Windows.Forms.TextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.txtFeriasLiquido = new System.Windows.Forms.TextBox();
            this.txt13Liquido = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdSalarioLiquido = new System.Windows.Forms.RadioButton();
            this.rdFeriasLiquido = new System.Windows.Forms.RadioButton();
            this.rd13Liquido = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(162, 13);
            this.txtSalarioBruto.MaxLength = 11;
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(88, 20);
            this.txtSalarioBruto.TabIndex = 0;
            this.txtSalarioBruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBonus
            // 
            this.txtBonus.Location = new System.Drawing.Point(162, 39);
            this.txtBonus.MaxLength = 11;
            this.txtBonus.Name = "txtBonus";
            this.txtBonus.Size = new System.Drawing.Size(88, 20);
            this.txtBonus.TabIndex = 1;
            this.txtBonus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtMesesTrabalhados
            // 
            this.txtMesesTrabalhados.Location = new System.Drawing.Point(162, 65);
            this.txtMesesTrabalhados.MaxLength = 11;
            this.txtMesesTrabalhados.Name = "txtMesesTrabalhados";
            this.txtMesesTrabalhados.ReadOnly = true;
            this.txtMesesTrabalhados.Size = new System.Drawing.Size(88, 20);
            this.txtMesesTrabalhados.TabIndex = 2;
            this.txtMesesTrabalhados.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDiasDeFerias
            // 
            this.txtDiasDeFerias.Location = new System.Drawing.Point(162, 91);
            this.txtDiasDeFerias.MaxLength = 11;
            this.txtDiasDeFerias.Name = "txtDiasDeFerias";
            this.txtDiasDeFerias.ReadOnly = true;
            this.txtDiasDeFerias.Size = new System.Drawing.Size(87, 20);
            this.txtDiasDeFerias.TabIndex = 3;
            this.txtDiasDeFerias.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtINSS
            // 
            this.txtINSS.Location = new System.Drawing.Point(162, 117);
            this.txtINSS.MaxLength = 11;
            this.txtINSS.Name = "txtINSS";
            this.txtINSS.ReadOnly = true;
            this.txtINSS.Size = new System.Drawing.Size(87, 20);
            this.txtINSS.TabIndex = 4;
            this.txtINSS.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBaseDeCalculo
            // 
            this.txtBaseDeCalculo.Location = new System.Drawing.Point(162, 143);
            this.txtBaseDeCalculo.MaxLength = 11;
            this.txtBaseDeCalculo.Name = "txtBaseDeCalculo";
            this.txtBaseDeCalculo.ReadOnly = true;
            this.txtBaseDeCalculo.Size = new System.Drawing.Size(87, 20);
            this.txtBaseDeCalculo.TabIndex = 5;
            this.txtBaseDeCalculo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtIRRF
            // 
            this.txtIRRF.Location = new System.Drawing.Point(163, 169);
            this.txtIRRF.MaxLength = 11;
            this.txtIRRF.Name = "txtIRRF";
            this.txtIRRF.ReadOnly = true;
            this.txtIRRF.Size = new System.Drawing.Size(87, 20);
            this.txtIRRF.TabIndex = 6;
            this.txtIRRF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Location = new System.Drawing.Point(163, 195);
            this.txtSalarioLiquido.MaxLength = 11;
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.ReadOnly = true;
            this.txtSalarioLiquido.Size = new System.Drawing.Size(87, 20);
            this.txtSalarioLiquido.TabIndex = 7;
            this.txtSalarioLiquido.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtFeriasLiquido
            // 
            this.txtFeriasLiquido.Location = new System.Drawing.Point(163, 221);
            this.txtFeriasLiquido.MaxLength = 11;
            this.txtFeriasLiquido.Name = "txtFeriasLiquido";
            this.txtFeriasLiquido.ReadOnly = true;
            this.txtFeriasLiquido.Size = new System.Drawing.Size(87, 20);
            this.txtFeriasLiquido.TabIndex = 8;
            this.txtFeriasLiquido.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt13Liquido
            // 
            this.txt13Liquido.Location = new System.Drawing.Point(163, 247);
            this.txt13Liquido.MaxLength = 11;
            this.txt13Liquido.Name = "txt13Liquido";
            this.txt13Liquido.ReadOnly = true;
            this.txt13Liquido.Size = new System.Drawing.Size(87, 20);
            this.txt13Liquido.TabIndex = 9;
            this.txt13Liquido.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Image = ((System.Drawing.Image)(resources.GetObject("btnCalcular.Image")));
            this.btnCalcular.Location = new System.Drawing.Point(6, 22);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(175, 59);
            this.btnCalcular.TabIndex = 12;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Image = ((System.Drawing.Image)(resources.GetObject("btnLimpar.Image")));
            this.btnLimpar.Location = new System.Drawing.Point(6, 87);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(98, 54);
            this.btnLimpar.TabIndex = 13;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnExit
            // 
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.Location = new System.Drawing.Point(110, 87);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(71, 54);
            this.btnExit.TabIndex = 14;
            this.btnExit.Text = "Sair";
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Salário bruto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Bônus";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Número de Meses Trabalhado";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Dias de Férias";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "INSS";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 146);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Base de Cálculo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 171);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "IRRF";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Salário Líquido";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 224);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Férias Líquido";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 250);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(97, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "13º Salário Líquido";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rd13Liquido);
            this.groupBox1.Controls.Add(this.rdFeriasLiquido);
            this.groupBox1.Controls.Add(this.rdSalarioLiquido);
            this.groupBox1.Location = new System.Drawing.Point(287, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(190, 94);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipo de Cálculo";
            // 
            // rdSalarioLiquido
            // 
            this.rdSalarioLiquido.AutoSize = true;
            this.rdSalarioLiquido.Checked = true;
            this.rdSalarioLiquido.Location = new System.Drawing.Point(13, 19);
            this.rdSalarioLiquido.Name = "rdSalarioLiquido";
            this.rdSalarioLiquido.Size = new System.Drawing.Size(96, 17);
            this.rdSalarioLiquido.TabIndex = 0;
            this.rdSalarioLiquido.TabStop = true;
            this.rdSalarioLiquido.Text = "Salário Líquido";
            this.rdSalarioLiquido.UseVisualStyleBackColor = true;
            this.rdSalarioLiquido.CheckedChanged += new System.EventHandler(this.rdSalarioLiquido_CheckedChanged);
            // 
            // rdFeriasLiquido
            // 
            this.rdFeriasLiquido.AutoSize = true;
            this.rdFeriasLiquido.Location = new System.Drawing.Point(13, 42);
            this.rdFeriasLiquido.Name = "rdFeriasLiquido";
            this.rdFeriasLiquido.Size = new System.Drawing.Size(92, 17);
            this.rdFeriasLiquido.TabIndex = 1;
            this.rdFeriasLiquido.TabStop = true;
            this.rdFeriasLiquido.Text = "Férias Líquido";
            this.rdFeriasLiquido.UseVisualStyleBackColor = true;
            this.rdFeriasLiquido.CheckedChanged += new System.EventHandler(this.rdFeriasLiquido_CheckedChanged);
            // 
            // rd13Liquido
            // 
            this.rd13Liquido.AutoSize = true;
            this.rd13Liquido.Location = new System.Drawing.Point(13, 65);
            this.rd13Liquido.Name = "rd13Liquido";
            this.rd13Liquido.Size = new System.Drawing.Size(115, 17);
            this.rd13Liquido.TabIndex = 2;
            this.rd13Liquido.TabStop = true;
            this.rd13Liquido.Text = "13º Salário Líquido";
            this.rd13Liquido.UseVisualStyleBackColor = true;
            this.rd13Liquido.CheckedChanged += new System.EventHandler(this.rd13Liquido_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCalcular);
            this.groupBox2.Controls.Add(this.btnLimpar);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Location = new System.Drawing.Point(287, 132);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 155);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ações";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtSalarioBruto);
            this.groupBox3.Controls.Add(this.txtBonus);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtMesesTrabalhados);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.txtDiasDeFerias);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.txtINSS);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.txtBaseDeCalculo);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.txtIRRF);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtSalarioLiquido);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.txtFeriasLiquido);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txt13Liquido);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(12, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(256, 275);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Parâmetros";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 302);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de cálculo de Salário Líquido e 13º Salário Liquido";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPrincipal_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.TextBox txtBonus;
        private System.Windows.Forms.TextBox txtMesesTrabalhados;
        private System.Windows.Forms.TextBox txtDiasDeFerias;
        private System.Windows.Forms.TextBox txtINSS;
        private System.Windows.Forms.TextBox txtBaseDeCalculo;
        private System.Windows.Forms.TextBox txtIRRF;
        private System.Windows.Forms.TextBox txtSalarioLiquido;
        private System.Windows.Forms.TextBox txtFeriasLiquido;
        private System.Windows.Forms.TextBox txt13Liquido;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rd13Liquido;
        private System.Windows.Forms.RadioButton rdFeriasLiquido;
        private System.Windows.Forms.RadioButton rdSalarioLiquido;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}

